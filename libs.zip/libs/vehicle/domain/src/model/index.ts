export { Vehicle } from './Vehicle';
export { VehicleSize } from './VehicleSize';
