export enum VehicleSize {
  SMALL,
  MEDIUM,
  LARGE
}
